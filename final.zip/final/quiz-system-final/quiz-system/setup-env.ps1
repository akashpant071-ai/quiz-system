# Creates server\.env for Supabase. Reads the password from an environment variable
# (set by START.bat), URL-encodes it, and adds a random JWT secret.
$ErrorActionPreference = 'Stop'
if (-not $env:QUIZ_DB_PASSWORD) { Write-Host 'No password entered.'; exit 1 }
$pw  = [uri]::EscapeDataString($env:QUIZ_DB_PASSWORD.Trim())
$jwt = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
$host_ = 'aws-0-ap-northeast-2.pooler.supabase.com'
$user  = 'postgres.yatmdmympanxsxocqbmo'
$lines = @(
  'PORT=5000',
  "DATABASE_URL=postgresql://${user}:${pw}@${host_}:5432/postgres?sslmode=no-verify",
  "JWT_SECRET=$jwt",
  'JWT_EXPIRES_IN=8h',
  'CLIENT_URL=http://localhost:5173'
)
Set-Content -Path (Join-Path $PSScriptRoot 'server\.env') -Value $lines -Encoding ascii
Write-Host 'server\.env created.'
