import { useState } from 'react';
import { api, errMsg } from '../api.js';
import { Alert, Modal } from './ui.jsx';

// Uploads a CSV and shows how many rows were imported and which rows failed
export default function ImportModal({ title, endpoint, columns, sample, onClose, onDone }) {
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  const upload = async (e) => {
    e.preventDefault();
    if (!file) return setError('Choose a CSV file first.');
    setBusy(true); setError(''); setResult(null);
    try {
      const form = new FormData();
      form.append('file', file);
      const r = await api(endpoint, { method: 'POST', form });
      setResult(r);
      if (r.imported) onDone();
    } catch (err) { setError(errMsg(err)); }
    finally { setBusy(false); }
  };

  return (
    <Modal title={title} onClose={onClose} wide>
      <form onSubmit={upload}>
        <p className="hint">Required columns: <code>{columns}</code>. Maximum 500 rows. Sample file: <code>{sample}</code></p>
        <input type="file" accept=".csv" onChange={(e) => { setFile(e.target.files[0] || null); setResult(null); }} />
        <Alert>{error}</Alert>
        {result && (
          <div className="import-result">
            <Alert type={result.imported ? 'success' : 'warn'}>
              {result.imported} row(s) imported, {result.failed.length} row(s) skipped.
              {result.note ? ` ${result.note}.` : ''}
            </Alert>
            {result.failed.length > 0 && (
              <table className="table compact">
                <thead><tr><th>Row</th><th>Problem</th></tr></thead>
                <tbody>{result.failed.map((f) => <tr key={f.row}><td>{f.row}</td><td>{f.errors.join('; ')}</td></tr>)}</tbody>
              </table>
            )}
          </div>
        )}
        <div className="modal-actions">
          <button type="button" className="btn btn-light" onClick={onClose}>Close</button>
          <button className="btn" disabled={busy}>{busy ? 'Importing...' : 'Import file'}</button>
        </div>
      </form>
    </Modal>
  );
}
