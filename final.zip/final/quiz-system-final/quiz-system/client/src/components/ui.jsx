import { useEffect } from 'react';

export function Modal({ title, onClose, children, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose} aria-label="Close">×</button></div>
        {children}
      </div>
    </div>
  );
}

export const Field = ({ label, children }) => (
  <label className="field"><span>{label}</span>{children}</label>
);

export const Alert = ({ type = 'error', children }) => (children ? <div className={`alert alert-${type}`}>{children}</div> : null);

export function Pager({ pagination, onPage }) {
  if (!pagination || pagination.total === 0) return null;
  const { page, limit, total, totalPages } = pagination;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  return (
    <div className="pager">
      <span>{from}-{to} of {total}</span>
      <div>
        <button className="btn btn-light" disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</button>
        <span className="page-num">Page {page} of {totalPages}</span>
        <button className="btn btn-light" disabled={page >= totalPages} onClick={() => onPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}

export const Empty = ({ children }) => <div className="empty">{children}</div>;

export const Badge = ({ tone = 'grey', children }) => <span className={`badge badge-${tone}`}>{children}</span>;

export const SortTh = ({ label, field, sort, order, onSort }) => (
  <th className="sortable" onClick={() => onSort(field)} aria-sort={sort === field ? (order === 'asc' ? 'ascending' : 'descending') : 'none'}>
    {label}{sort === field ? (order === 'asc' ? ' ▲' : ' ▼') : ''}
  </th>
);
