import { useEffect, useState } from 'react';

export const qs = (obj) =>
  new URLSearchParams(Object.entries(obj).filter(([, v]) => v !== '' && v != null)).toString();

export const errMsg = (e) => (e.data?.details?.length ? e.data.details.join('. ') : e.message);

// Fetch wrapper: adds the token, parses JSON, throws Error with .status and .data
export async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {};
  const token = localStorage.getItem('token');
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }

  let res;
  try { res = await fetch(`/api${path}`, { method, headers, body: payload }); }
  catch { throw new Error('Cannot reach the server. Check that the API is running.'); }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && !path.startsWith('/auth/login')) {
      localStorage.removeItem('token');
      window.location.assign('/login');
    }
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

// Downloads a file (e.g. CSV) from an authenticated endpoint
export async function download(path) {
  const res = await fetch(`/api${path}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Download failed');
  const name = /filename="(.+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || 'export.csv';
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  a.click();
  URL.revokeObjectURL(url);
}

// Loads data whenever path or params change; ignores stale responses
export function useFetch(path, params = {}) {
  const [state, setState] = useState({ data: null, loading: true, error: '' });
  const [tick, setTick] = useState(0);
  const key = path ? `${path}?${qs(params)}` : null;
  useEffect(() => {
    if (!key) return undefined;
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: '' }));
    api(key)
      .then((data) => alive && setState({ data, loading: false, error: '' }))
      .catch((e) => alive && setState((s) => ({ ...s, loading: false, error: e.message })));
    return () => { alive = false; };
  }, [key, tick]);
  return { ...state, reload: () => setTick((t) => t + 1) };
}

export function useDebounce(value, delay = 300) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), delay); return () => clearTimeout(t); }, [value, delay]);
  return v;
}

export const fmtDate = (d) => (d ? new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '-');
