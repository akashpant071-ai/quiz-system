import { Link, useParams } from 'react-router-dom';
import { fmtDate, useFetch } from '../api.js';
import { useAuth } from '../auth.jsx';
import { Alert, Badge } from '../components/ui.jsx';

export default function ResultView() {
  const { id } = useParams();
  const { user } = useAuth();
  const { data: r, loading, error } = useFetch(`/attempts/${id}/result`);
  if (loading && !r) return <p>Loading...</p>;
  if (error) return <><Alert>{error}</Alert><Link to="/">Back</Link></>;

  return (
    <>
      <p className="crumb"><Link to={user.role === 'teacher' ? '/results' : '/my-results'}>Results</Link> / {r.quiz}</p>
      <div className="page-head">
        <h1>{r.quiz}</h1>
        <Badge tone={r.passed ? 'green' : 'red'}>{r.passed ? 'Passed' : 'Not passed'}</Badge>
      </div>
      <div className="stat-grid small">
        <div className="stat"><span>Score</span><strong>{r.score} / {r.total_marks}</strong></div>
        <div className="stat"><span>Percent</span><strong>{r.percent}%</strong></div>
        <div className="stat"><span>Pass marks</span><strong>{r.pass_marks}</strong></div>
        <div className="stat"><span>Student</span><strong className="plain">{r.student} ({r.roll_no})</strong></div>
      </div>
      <p className="hint">Submitted {fmtDate(r.submitted_at)}</p>
      <h2>Answer review</h2>
      {r.review.map((q, i) => (
        <section className="panel review" key={q.question_id}>
          <p className="q-text">{i + 1}. {q.text} <Badge tone={q.is_correct ? 'green' : 'red'}>{q.is_correct ? `+${q.marks}` : '0'}</Badge></p>
          {['A', 'B', 'C', 'D'].map((l) => {
            const cls = l === q.correct_option ? 'correct' : l === q.selected_option ? 'wrong' : '';
            return (
              <div key={l} className={`option static ${cls}`}>
                <b>{l}.</b> {q[`option_${l.toLowerCase()}`]}
                {l === q.correct_option && <em> Correct answer</em>}
                {l === q.selected_option && l !== q.correct_option && <em> Your answer</em>}
              </div>
            );
          })}
          {!q.selected_option && <p className="hint">Not answered.</p>}
        </section>
      ))}
    </>
  );
}
