import { useState } from 'react';
import { api, errMsg, fmtDate, useDebounce, useFetch } from '../api.js';
import { Alert, Empty, Field, Modal, Pager, SortTh } from '../components/ui.jsx';
import ImportModal from '../components/ImportModal.jsx';

const BLANK = { name: '', email: '', roll_no: '', password: '' };

export default function Students() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('created_at');
  const [order, setOrder] = useState('desc');
  const q = useDebounce(search);
  const { data, loading, error, reload } = useFetch('/students', { search: q, page, sort, order, limit: 10 });
  const [editing, setEditing] = useState(null); // null | {} (new) | student
  const [importing, setImporting] = useState(false);
  const [notice, setNotice] = useState('');

  const onSort = (field) => {
    if (sort === field) setOrder(order === 'asc' ? 'desc' : 'asc'); else { setSort(field); setOrder('asc'); }
    setPage(1);
  };
  const remove = async (s) => {
    if (!window.confirm(`Delete ${s.name}? Their quiz attempts and results will also be deleted.`)) return;
    try { await api(`/students/${s.id}`, { method: 'DELETE' }); setNotice(`Deleted ${s.name}.`); reload(); }
    catch (e) { setNotice(e.message); }
  };

  return (
    <>
      <div className="page-head">
        <h1>Students</h1>
        <div className="actions">
          <button className="btn btn-light" onClick={() => setImporting(true)}>Import CSV</button>
          <button className="btn" onClick={() => setEditing({})}>Add student</button>
        </div>
      </div>
      <div className="toolbar">
        <input type="search" placeholder="Search by name, email or roll number" value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
      </div>
      <Alert type="info">{notice}</Alert>
      <Alert>{error}</Alert>
      <div className="table-wrap">
        <table className="table">
          <thead><tr>
            <SortTh label="Roll no" field="roll_no" {...{ sort, order, onSort }} />
            <SortTh label="Name" field="name" {...{ sort, order, onSort }} />
            <th>Email</th>
            <SortTh label="Added" field="created_at" {...{ sort, order, onSort }} />
            <th></th>
          </tr></thead>
          <tbody>
            {data?.data.map((s) => (
              <tr key={s.id}>
                <td>{s.roll_no}</td><td>{s.name}</td><td>{s.email}</td><td>{fmtDate(s.created_at)}</td>
                <td className="row-actions">
                  <button className="link" onClick={() => setEditing(s)}>Edit</button>
                  <button className="link danger" onClick={() => remove(s)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && data?.data.length === 0 && (
          <Empty>{q ? 'No students match your search.' : 'No students yet. Add one or import a CSV file.'}</Empty>
        )}
      </div>
      <Pager pagination={data?.pagination} onPage={setPage} />
      {editing && <StudentForm student={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} />}
      {importing && (
        <ImportModal title="Import students" endpoint="/students/import" columns="name, email, roll_no (password optional)"
          sample="docs/samples/students_sample.csv" onClose={() => setImporting(false)} onDone={reload} />
      )}
    </>
  );
}

function StudentForm({ student, onClose, onSaved }) {
  const isNew = !student.id;
  const [form, setForm] = useState(isNew ? BLANK : { name: student.name, email: student.email, roll_no: student.roll_no, password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    const body = { ...form };
    if (!isNew && !body.password) delete body.password;
    try {
      await api(isNew ? '/students' : `/students/${student.id}`, { method: isNew ? 'POST' : 'PUT', body });
      onSaved();
    } catch (err) { setError(errMsg(err)); setBusy(false); }
  };

  return (
    <Modal title={isNew ? 'Add student' : 'Edit student'} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Full name"><input required value={form.name} onChange={set('name')} /></Field>
        <Field label="Email"><input type="email" required value={form.email} onChange={set('email')} /></Field>
        <Field label="Roll number"><input required value={form.roll_no} onChange={set('roll_no')} /></Field>
        <Field label={isNew ? 'Password (min 8 characters)' : 'New password (leave blank to keep current)'}>
          <input type="password" minLength={8} required={isNew} value={form.password} onChange={set('password')} autoComplete="new-password" />
        </Field>
        <Alert>{error}</Alert>
        <div className="modal-actions">
          <button type="button" className="btn btn-light" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Saving...' : 'Save student'}</button>
        </div>
      </form>
    </Modal>
  );
}
