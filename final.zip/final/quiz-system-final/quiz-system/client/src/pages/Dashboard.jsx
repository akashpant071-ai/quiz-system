import { Link } from 'react-router-dom';
import { fmtDate, useFetch } from '../api.js';
import { Alert, Badge, Empty } from '../components/ui.jsx';

const pct = (v) => (v == null ? '-' : `${v}%`);

export default function Dashboard() {
  const { data, loading, error } = useFetch('/dashboard');
  if (loading && !data) return <p>Loading...</p>;
  if (error) return <Alert>{error}</Alert>;
  const { totals: t, recent_attempts: recent, quiz_stats: stats } = data;
  const cards = [
    ['Students', t.students], ['Quizzes', `${t.published_quizzes} / ${t.quizzes} published`], ['Questions', t.questions],
    ['Attempts', t.attempts], ['Average score', pct(t.avg_percent)], ['Pass rate', pct(t.pass_rate)],
  ];
  return (
    <>
      <h1>Dashboard</h1>
      <div className="stat-grid">
        {cards.map(([label, value]) => (
          <div className="stat" key={label}><span>{label}</span><strong>{value}</strong></div>
        ))}
      </div>
      <div className="two-col">
        <section className="panel">
          <h2>Recent attempts</h2>
          {recent.length === 0 ? <Empty>No attempts yet. Publish a quiz and ask students to take it.</Empty> : (
            <table className="table">
              <thead><tr><th>Student</th><th>Quiz</th><th>Score</th><th>Result</th><th>Submitted</th></tr></thead>
              <tbody>{recent.map((r) => (
                <tr key={r.id}>
                  <td>{r.student}</td><td>{r.quiz}</td>
                  <td><Link to={`/result/${r.id}`}>{r.score}/{r.total_marks}</Link></td>
                  <td><Badge tone={r.passed ? 'green' : 'red'}>{r.passed ? 'Pass' : 'Fail'}</Badge></td>
                  <td>{fmtDate(r.submitted_at)}</td>
                </tr>))}</tbody>
            </table>
          )}
        </section>
        <section className="panel">
          <h2>Most attempted quizzes</h2>
          {stats.length === 0 ? <Empty>Quiz statistics appear after the first submission.</Empty> : (
            <table className="table">
              <thead><tr><th>Quiz</th><th>Attempts</th><th>Average</th><th>Pass rate</th></tr></thead>
              <tbody>{stats.map((s) => (
                <tr key={s.id}><td>{s.title}</td><td>{s.attempts}</td><td>{pct(s.avg_percent)}</td><td>{pct(s.pass_rate)}</td></tr>
              ))}</tbody>
            </table>
          )}
        </section>
      </div>
    </>
  );
}
