import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, errMsg, useDebounce, useFetch } from '../api.js';
import { Alert, Badge, Empty, Field, Modal, Pager } from '../components/ui.jsx';

export default function Quizzes() {
  const [search, setSearch] = useState('');
  const [published, setPublished] = useState('');
  const [page, setPage] = useState(1);
  const q = useDebounce(search);
  const { data, loading, error, reload } = useFetch('/quizzes', { search: q, published, page, limit: 10 });
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState({ type: 'info', text: '' });
  const say = (type, text) => setNotice({ type, text });

  const togglePublish = async (quiz) => {
    try {
      await api(`/quizzes/${quiz.id}/publish`, { method: 'PATCH', body: { is_published: !quiz.is_published } });
      say('success', quiz.is_published ? `Unpublished "${quiz.title}".` : `Published "${quiz.title}".`);
      reload();
    } catch (e) { say('error', e.message); }
  };
  const remove = async (quiz) => {
    if (!window.confirm(`Delete "${quiz.title}"? Its questions and all student results will be deleted.`)) return;
    try { await api(`/quizzes/${quiz.id}`, { method: 'DELETE' }); say('success', `Deleted "${quiz.title}".`); reload(); }
    catch (e) { say('error', e.message); }
  };

  return (
    <>
      <div className="page-head">
        <h1>Quizzes</h1>
        <button className="btn" onClick={() => setEditing({})}>Create quiz</button>
      </div>
      <div className="toolbar">
        <input type="search" placeholder="Search by title" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        <select value={published} onChange={(e) => { setPublished(e.target.value); setPage(1); }} aria-label="Filter by status">
          <option value="">All statuses</option><option value="true">Published</option><option value="false">Draft</option>
        </select>
      </div>
      <Alert type={notice.type}>{notice.text}</Alert>
      <Alert>{error}</Alert>
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Title</th><th>Duration</th><th>Questions</th><th>Total marks</th><th>Pass marks</th><th>Attempts</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {data?.data.map((z) => (
              <tr key={z.id}>
                <td>{z.title}</td><td>{z.duration_minutes} min</td><td>{z.question_count}</td>
                <td>{z.total_marks}</td><td>{z.pass_marks}</td><td>{z.attempt_count}</td>
                <td><Badge tone={z.is_published ? 'green' : 'grey'}>{z.is_published ? 'Published' : 'Draft'}</Badge></td>
                <td className="row-actions">
                  <Link to={`/quizzes/${z.id}/questions`}>Questions</Link>
                  <button className="link" onClick={() => setEditing(z)}>Edit</button>
                  <button className="link" onClick={() => togglePublish(z)}>{z.is_published ? 'Unpublish' : 'Publish'}</button>
                  <button className="link danger" onClick={() => remove(z)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && data?.data.length === 0 && (
          <Empty>{q || published ? 'No quizzes match these filters.' : 'No quizzes yet. Create one, then add questions.'}</Empty>
        )}
      </div>
      <Pager pagination={data?.pagination} onPage={setPage} />
      {editing && <QuizForm quiz={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} />}
    </>
  );
}

function QuizForm({ quiz, onClose, onSaved }) {
  const isNew = !quiz.id;
  const [form, setForm] = useState({
    title: quiz.title || '', description: quiz.description || '',
    duration_minutes: quiz.duration_minutes ?? 10, pass_marks: quiz.pass_marks ?? 0,
  });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    const body = { ...form, duration_minutes: Number(form.duration_minutes), pass_marks: Number(form.pass_marks) };
    try { await api(isNew ? '/quizzes' : `/quizzes/${quiz.id}`, { method: isNew ? 'POST' : 'PUT', body }); onSaved(); }
    catch (err) { setError(errMsg(err)); setBusy(false); }
  };

  return (
    <Modal title={isNew ? 'Create quiz' : 'Edit quiz'} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Title"><input required minLength={3} value={form.title} onChange={set('title')} /></Field>
        <Field label="Description (optional)"><textarea rows={3} value={form.description} onChange={set('description')} /></Field>
        <div className="row-2">
          <Field label="Duration (minutes)"><input type="number" min={1} max={300} required value={form.duration_minutes} onChange={set('duration_minutes')} /></Field>
          <Field label="Pass marks"><input type="number" min={0} required value={form.pass_marks} onChange={set('pass_marks')} /></Field>
        </div>
        <Alert>{error}</Alert>
        <div className="modal-actions">
          <button type="button" className="btn btn-light" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Saving...' : 'Save quiz'}</button>
        </div>
      </form>
    </Modal>
  );
}
