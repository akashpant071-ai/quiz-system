import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, errMsg, useDebounce, useFetch } from '../api.js';
import { Alert, Empty, Field, Modal, Pager } from '../components/ui.jsx';
import ImportModal from '../components/ImportModal.jsx';

const BLANK = { text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A', marks: 1 };

export default function QuizQuestions() {
  const { quizId } = useParams();
  const quiz = useFetch(`/quizzes/${quizId}`);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const q = useDebounce(search);
  const { data, loading, error, reload } = useFetch(`/quizzes/${quizId}/questions`, { search: q, page, limit: 10 });
  const [editing, setEditing] = useState(null);
  const [importing, setImporting] = useState(false);
  const [notice, setNotice] = useState('');
  const refresh = () => { reload(); quiz.reload(); };

  const remove = async (item) => {
    if (!window.confirm('Delete this question?')) return;
    try { await api(`/questions/${item.id}`, { method: 'DELETE' }); setNotice(''); refresh(); }
    catch (e) { setNotice(e.message); }
  };
  const z = quiz.data;

  return (
    <>
      <p className="crumb"><Link to="/quizzes">Quizzes</Link> / {z?.title}</p>
      <div className="page-head">
        <h1>Questions{z ? `: ${z.title}` : ''}</h1>
        <div className="actions">
          <button className="btn btn-light" onClick={() => setImporting(true)}>Import CSV</button>
          <button className="btn" onClick={() => setEditing({})}>Add question</button>
        </div>
      </div>
      {z && <p className="hint">{z.question_count} question(s), {z.total_marks} total marks, pass marks {z.pass_marks}. Questions are locked after the first student attempt.</p>}
      <div className="toolbar">
        <input type="search" placeholder="Search question text" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
      </div>
      <Alert>{notice || error}</Alert>
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Question</th><th>Options</th><th>Answer</th><th>Marks</th><th></th></tr></thead>
          <tbody>
            {data?.data.map((item) => (
              <tr key={item.id}>
                <td className="wrap">{item.text}</td>
                <td className="wrap small">A. {item.option_a}<br />B. {item.option_b}<br />C. {item.option_c}<br />D. {item.option_d}</td>
                <td>{item.correct_option}</td><td>{item.marks}</td>
                <td className="row-actions">
                  <button className="link" onClick={() => setEditing(item)}>Edit</button>
                  <button className="link danger" onClick={() => remove(item)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && data?.data.length === 0 && (
          <Empty>{q ? 'No questions match your search.' : 'This quiz has no questions. Add one or import a CSV file.'}</Empty>
        )}
      </div>
      <Pager pagination={data?.pagination} onPage={setPage} />
      {editing && <QuestionForm quizId={quizId} item={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); refresh(); }} />}
      {importing && (
        <ImportModal title="Import questions" endpoint={`/quizzes/${quizId}/questions/import`}
          columns="question, option_a, option_b, option_c, option_d, correct_option (marks optional)"
          sample="docs/samples/questions_sample.csv" onClose={() => setImporting(false)} onDone={refresh} />
      )}
    </>
  );
}

function QuestionForm({ quizId, item, onClose, onSaved }) {
  const isNew = !item.id;
  const [form, setForm] = useState(isNew ? BLANK : { ...BLANK, ...item });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    const { text, option_a, option_b, option_c, option_d, correct_option } = form;
    const body = { text, option_a, option_b, option_c, option_d, correct_option, marks: Number(form.marks) };
    try { await api(isNew ? `/quizzes/${quizId}/questions` : `/questions/${item.id}`, { method: isNew ? 'POST' : 'PUT', body }); onSaved(); }
    catch (err) { setError(errMsg(err)); setBusy(false); }
  };

  return (
    <Modal title={isNew ? 'Add question' : 'Edit question'} onClose={onClose} wide>
      <form onSubmit={submit}>
        <Field label="Question"><textarea required rows={3} value={form.text} onChange={set('text')} /></Field>
        <div className="row-2">
          {['a', 'b', 'c', 'd'].map((l) => (
            <Field key={l} label={`Option ${l.toUpperCase()}`}><input required value={form[`option_${l}`]} onChange={set(`option_${l}`)} /></Field>
          ))}
          <Field label="Correct answer">
            <select value={form.correct_option} onChange={set('correct_option')}>
              {['A', 'B', 'C', 'D'].map((l) => <option key={l}>{l}</option>)}
            </select>
          </Field>
          <Field label="Marks"><input type="number" min={1} max={100} required value={form.marks} onChange={set('marks')} /></Field>
        </div>
        <Alert>{error}</Alert>
        <div className="modal-actions">
          <button type="button" className="btn btn-light" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Saving...' : 'Save question'}</button>
        </div>
      </form>
    </Modal>
  );
}
