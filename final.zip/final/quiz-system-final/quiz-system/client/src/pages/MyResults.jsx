import { useState } from 'react';
import { Link } from 'react-router-dom';
import { fmtDate, useFetch } from '../api.js';
import { Alert, Badge, Empty, Pager } from '../components/ui.jsx';

export default function MyResults() {
  const [page, setPage] = useState(1);
  const { data, loading, error } = useFetch('/attempts/mine', { page, limit: 10 });
  return (
    <>
      <h1>My results</h1>
      <Alert>{error}</Alert>
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Quiz</th><th>Score</th><th>Percent</th><th>Result</th><th>Submitted</th><th></th></tr></thead>
          <tbody>
            {data?.data.map((r) => (
              <tr key={r.id}>
                <td>{r.quiz}</td><td>{r.score}/{r.total_marks}</td><td>{r.percent}%</td>
                <td><Badge tone={r.passed ? 'green' : 'red'}>{r.passed ? 'Pass' : 'Fail'}</Badge></td>
                <td>{fmtDate(r.submitted_at)}</td>
                <td className="row-actions"><Link to={`/result/${r.id}`}>View</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && data?.data.length === 0 && <Empty>You have not completed any quizzes yet. Start one from My quizzes.</Empty>}
      </div>
      <Pager pagination={data?.pagination} onPage={setPage} />
    </>
  );
}
