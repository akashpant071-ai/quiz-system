import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { Alert } from '../components/ui.jsx';

const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

export default function TakeQuiz() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [answers, setAnswers] = useState({});
  const [index, setIndex] = useState(0);
  const [left, setLeft] = useState(0);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const endsAt = useRef(0);
  const answersRef = useRef({});
  const submitted = useRef(false);

  // Start or resume the attempt
  useEffect(() => {
    let alive = true;
    api('/attempts/start', { method: 'POST', body: { quiz_id: Number(quizId) } })
      .then((s) => {
        if (!alive) return;
        const saved = Object.fromEntries(s.saved_answers.map((a) => [a.question_id, a.selected_option]));
        answersRef.current = saved;
        setAnswers(saved);
        endsAt.current = Date.now() + s.remaining_seconds * 1000;
        setLeft(s.remaining_seconds);
        setSession(s);
      })
      .catch((e) => {
        if (e.status === 409 && e.data?.attempt_id) navigate(`/result/${e.data.attempt_id}`, { replace: true });
        else if (alive) setError(e.message);
      });
    return () => { alive = false; };
  }, [quizId, navigate]);

  const submit = useCallback(async () => {
    if (submitted.current || !session) return;
    submitted.current = true;
    setSubmitting(true);
    try {
      const list = Object.entries(answersRef.current).map(([question_id, selected_option]) => ({ question_id: Number(question_id), selected_option }));
      await api(`/attempts/${session.attempt_id}/submit`, { method: 'POST', body: { answers: list } });
      navigate(`/result/${session.attempt_id}`, { replace: true });
    } catch (e) {
      submitted.current = false;
      setSubmitting(false);
      setError(`${e.message} Your answers are saved. Try submitting again.`);
    }
  }, [session, navigate]);

  // Countdown based on the end time (not a counter), so tab throttling cannot slow it down
  useEffect(() => {
    if (!session) return undefined;
    const t = setInterval(() => {
      const s = Math.max(0, Math.ceil((endsAt.current - Date.now()) / 1000));
      setLeft(s);
      if (s === 0) { clearInterval(t); submit(); }
    }, 500);
    return () => clearInterval(t);
  }, [session, submit]);

  useEffect(() => {
    const warn = (e) => { if (!submitted.current) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, []);

  const choose = async (qid, opt) => {
    answersRef.current = { ...answersRef.current, [qid]: opt };
    setAnswers(answersRef.current);
    try { await api(`/attempts/${session.attempt_id}/answer`, { method: 'PUT', body: { question_id: qid, selected_option: opt } }); }
    catch (e) {
      if (e.status === 409 && e.data?.attempt_id) navigate(`/result/${e.data.attempt_id}`, { replace: true });
      else setError(`Answer not saved: ${e.message}`);
    }
  };

  const finish = () => {
    const unanswered = session.questions.length - Object.keys(answers).length;
    const msg = unanswered ? `You have ${unanswered} unanswered question(s). Submit anyway?` : 'Submit your answers now?';
    if (window.confirm(msg)) submit();
  };

  if (error && !session) return <><Alert>{error}</Alert><button className="btn btn-light" onClick={() => navigate('/')}>Back to quizzes</button></>;
  if (!session) return <p>Starting quiz...</p>;

  const total = session.questions.length;
  const ques = session.questions[index];
  const opts = [['A', ques.option_a], ['B', ques.option_b], ['C', ques.option_c], ['D', ques.option_d]];

  return (
    <>
      <div className="quiz-bar">
        <div><h1>{session.quiz.title}</h1><span className="hint">Question {index + 1} of {total}, {ques.marks} mark(s)</span></div>
        <div className={`timer ${left <= 60 ? 'timer-low' : ''}`} role="timer" aria-label="Time left">{fmt(left)}</div>
      </div>
      <Alert>{error}</Alert>
      <section className="panel question">
        <p className="q-text">{ques.text}</p>
        {opts.map(([letter, text]) => (
          <label key={letter} className={`option ${answers[ques.id] === letter ? 'selected' : ''}`}>
            <input type="radio" name={`q${ques.id}`} checked={answers[ques.id] === letter} onChange={() => choose(ques.id, letter)} disabled={submitting} />
            <b>{letter}.</b> {text}
          </label>
        ))}
      </section>
      <div className="quiz-nav">
        <button className="btn btn-light" disabled={index === 0} onClick={() => setIndex(index - 1)}>Previous</button>
        <button className="btn btn-light" disabled={index === total - 1} onClick={() => setIndex(index + 1)}>Next</button>
        <button className="btn btn-submit" onClick={finish} disabled={submitting}>{submitting ? 'Submitting...' : 'Submit quiz'}</button>
      </div>
      <div className="palette" aria-label="Question navigator">
        {session.questions.map((x, i) => (
          <button key={x.id} className={`pal ${answers[x.id] ? 'done' : ''} ${i === index ? 'current' : ''}`} onClick={() => setIndex(i)} aria-label={`Question ${i + 1}${answers[x.id] ? ', answered' : ''}`}>{i + 1}</button>
        ))}
      </div>
    </>
  );
}
