import { useState } from 'react';
import { Link } from 'react-router-dom';
import { download, fmtDate, qs, useDebounce, useFetch } from '../api.js';
import { Alert, Badge, Empty, Pager, SortTh } from '../components/ui.jsx';

export default function Results() {
  const [f, setF] = useState({ quiz_id: '', result: '', from: '', to: '' });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('submitted_at');
  const [order, setOrder] = useState('desc');
  const [exportError, setExportError] = useState('');
  const q = useDebounce(search);
  const quizzes = useFetch('/quizzes', { limit: 100 });
  const filters = { ...f, search: q, sort, order };
  const { data, loading, error } = useFetch('/reports/results', { ...filters, page, limit: 10 });

  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(1); };
  const onSort = (field) => {
    if (sort === field) setOrder(order === 'asc' ? 'desc' : 'asc'); else { setSort(field); setOrder('desc'); }
    setPage(1);
  };
  const exportCsv = async () => {
    setExportError('');
    try { await download(`/reports/results/export?${qs(filters)}`); } catch (e) { setExportError(e.message); }
  };
  const s = data?.summary;

  return (
    <>
      <div className="page-head">
        <h1>Results</h1>
        <button className="btn" onClick={exportCsv} disabled={!data?.pagination.total}>Export CSV</button>
      </div>
      <div className="toolbar wrap-toolbar">
        <input type="search" placeholder="Search student name, roll number or email" value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        <select value={f.quiz_id} onChange={set('quiz_id')} aria-label="Filter by quiz">
          <option value="">All quizzes</option>
          {quizzes.data?.data.map((z) => <option key={z.id} value={z.id}>{z.title}</option>)}
        </select>
        <select value={f.result} onChange={set('result')} aria-label="Filter by result">
          <option value="">Pass and fail</option><option value="pass">Pass only</option><option value="fail">Fail only</option>
        </select>
        <label className="inline">From <input type="date" value={f.from} onChange={set('from')} /></label>
        <label className="inline">To <input type="date" value={f.to} onChange={set('to')} /></label>
      </div>
      {s && (
        <div className="stat-grid small">
          <div className="stat"><span>Attempts</span><strong>{s.attempts}</strong></div>
          <div className="stat"><span>Average score</span><strong>{s.avg_percent ?? '-'}{s.avg_percent != null && '%'}</strong></div>
          <div className="stat"><span>Pass rate</span><strong>{s.pass_rate ?? '-'}{s.pass_rate != null && '%'}</strong></div>
        </div>
      )}
      <Alert>{error || exportError}</Alert>
      <div className="table-wrap">
        <table className="table">
          <thead><tr>
            <SortTh label="Student" field="name" {...{ sort, order, onSort }} />
            <th>Roll no</th><th>Quiz</th>
            <SortTh label="Score" field="score" {...{ sort, order, onSort }} />
            <SortTh label="Percent" field="percent" {...{ sort, order, onSort }} />
            <th>Result</th>
            <SortTh label="Submitted" field="submitted_at" {...{ sort, order, onSort }} />
            <th></th>
          </tr></thead>
          <tbody>
            {data?.data.map((r) => (
              <tr key={r.id}>
                <td>{r.student}</td><td>{r.roll_no}</td><td>{r.quiz}</td><td>{r.score}/{r.total_marks}</td><td>{r.percent}%</td>
                <td><Badge tone={r.passed ? 'green' : 'red'}>{r.passed ? 'Pass' : 'Fail'}</Badge></td>
                <td>{fmtDate(r.submitted_at)}</td>
                <td className="row-actions"><Link to={`/result/${r.id}`}>View</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && data?.data.length === 0 && <Empty>No results match these filters.</Empty>}
      </div>
      <Pager pagination={data?.pagination} onPage={setPage} />
    </>
  );
}
