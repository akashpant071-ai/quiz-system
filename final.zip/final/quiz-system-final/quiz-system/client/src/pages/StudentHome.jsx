import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDebounce, useFetch } from '../api.js';
import { Alert, Badge, Empty, Pager } from '../components/ui.jsx';

export default function StudentHome() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const q = useDebounce(search);
  const { data, loading, error } = useFetch('/quizzes', { search: q, page, limit: 9 });

  return (
    <>
      <h1>My quizzes</h1>
      <div className="toolbar">
        <input type="search" placeholder="Search quizzes" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
      </div>
      <Alert>{error}</Alert>
      <div className="card-grid">
        {data?.data.map((z) => (
          <div className="quiz-card" key={z.id}>
            <h2>{z.title}</h2>
            <p className="hint">{z.description || 'No description.'}</p>
            <p className="meta">{z.question_count} questions, {z.total_marks} marks, {z.duration_minutes} min, pass at {z.pass_marks}</p>
            <div className="card-foot">
              {z.attempt_status === 'submitted' && <><Badge tone="green">Completed</Badge><Link className="btn btn-light" to={`/result/${z.attempt_id}`}>View result</Link></>}
              {z.attempt_status === 'in_progress' && <><Badge tone="amber">In progress</Badge><Link className="btn" to={`/quiz/${z.id}`}>Resume quiz</Link></>}
              {!z.attempt_status && <><Badge>Not started</Badge><Link className="btn" to={`/quiz/${z.id}`}>Start quiz</Link></>}
            </div>
          </div>
        ))}
      </div>
      {!loading && data?.data.length === 0 && <Empty>{q ? 'No quizzes match your search.' : 'No quizzes are available yet. Check back after your teacher publishes one.'}</Empty>}
      <Pager pagination={data?.pagination} onPage={setPage} />
    </>
  );
}
