import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Students from './pages/Students.jsx';
import Quizzes from './pages/Quizzes.jsx';
import QuizQuestions from './pages/QuizQuestions.jsx';
import Results from './pages/Results.jsx';
import StudentHome from './pages/StudentHome.jsx';
import TakeQuiz from './pages/TakeQuiz.jsx';
import ResultView from './pages/ResultView.jsx';
import MyResults from './pages/MyResults.jsx';

function Protected({ role, children }) {
  const { user, ready } = useAuth();
  if (!ready) return <p className="center-note">Loading...</p>;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

function Home() {
  const { user } = useAuth();
  return user.role === 'teacher' ? <Dashboard /> : <StudentHome />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route index element={<Home />} />
        <Route path="students" element={<Protected role="teacher"><Students /></Protected>} />
        <Route path="quizzes" element={<Protected role="teacher"><Quizzes /></Protected>} />
        <Route path="quizzes/:quizId/questions" element={<Protected role="teacher"><QuizQuestions /></Protected>} />
        <Route path="results" element={<Protected role="teacher"><Results /></Protected>} />
        <Route path="my-results" element={<Protected role="student"><MyResults /></Protected>} />
        <Route path="quiz/:quizId" element={<Protected role="student"><TakeQuiz /></Protected>} />
        <Route path="result/:id" element={<ResultView />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
