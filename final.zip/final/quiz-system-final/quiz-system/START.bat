@echo off
setlocal
cd /d "%~dp0"
title Quiz System - Start

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install it from https://nodejs.org and run START.bat again.
  pause
  exit /b 1
)

if not exist "server\.env" (
  echo.
  echo Enter your Supabase database password. It is saved only on this computer.
  set /p QUIZ_DB_PASSWORD=Password: 
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-env.ps1"
  if errorlevel 1 (
    echo Could not create server\.env
    pause
    exit /b 1
  )
)

if not exist "server\node_modules" (
  echo.
  echo Installing server packages. This takes a minute...
  pushd server
  call npm.cmd install
  if errorlevel 1 (
    popd
    echo Server install failed.
    pause
    exit /b 1
  )
  popd
)

if not exist "client\node_modules" (
  echo.
  echo Installing client packages. This takes a minute...
  pushd client
  call npm.cmd install
  if errorlevel 1 (
    popd
    echo Client install failed.
    pause
    exit /b 1
  )
  popd
)

if not exist "server\.db_ready" (
  echo.
  echo Creating tables in Supabase...
  pushd server
  call npm.cmd run db:init
  if errorlevel 1 (
    popd
    echo.
    echo Could not connect to Supabase. Most likely the password is wrong.
    echo Delete the file server\.env and run START.bat again.
    pause
    exit /b 1
  )
  call npm.cmd run db:seed
  if errorlevel 1 (
    popd
    echo Adding demo data failed.
    pause
    exit /b 1
  )
  echo done> .db_ready
  popd
)

echo.
echo Starting the app. Two black windows will open. Keep them open.
start "Quiz API" cmd /k "cd /d %~dp0server && npm.cmd run dev"
start "Quiz Client" cmd /k "cd /d %~dp0client && npm.cmd run dev"
timeout /t 10 >nul
start http://localhost:5173
echo.
echo Login: teacher@quiz.local / Teacher@123
echo To stop the app, close the two black windows.
pause
