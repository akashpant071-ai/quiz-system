// Ensures the named route params are positive integers and converts them to numbers
export const validId = (...names) => (req, res, next) => {
  for (const name of names) {
    const value = Number(req.params[name]);
    if (!Number.isInteger(value) || value < 1) {
      return res.status(400).json({ error: `Invalid ${name}` });
    }
    req.params[name] = value;
  }
  next();
};
