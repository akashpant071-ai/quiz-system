import multer from 'multer';
import { HttpError } from '../utils/http.js';

// CSV upload kept in memory, max 1 MB, .csv only
export const csvUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024 },
  fileFilter: (_req, file, cb) =>
    /\.csv$/i.test(file.originalname) ? cb(null, true) : cb(new HttpError(400, 'Only .csv files are allowed')),
}).single('file');
