// Validates req.body against a zod schema and replaces it with the parsed value
export const validate = (schema) => (req, res, next) => {
  const result = schema.safeParse(req.body);
  if (!result.success) {
    const details = result.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`);
    return res.status(400).json({ error: 'Validation failed', details });
  }
  req.body = result.data;
  next();
};
