import { HttpError } from '../utils/http.js';

export function errorHandler(err, _req, res, _next) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, ...err.extra });
  if (err.name === 'MulterError') {
    return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File too large (max 1 MB)' : err.message });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON body' });
  if (err.code === '23505') {
    const c = err.constraint || '';
    const error = c.includes('email') ? 'Email already exists'
      : c.includes('roll_no') ? 'Roll number already exists' : 'Duplicate record';
    return res.status(409).json({ error });
  }
  if (err.code === '23503') return res.status(409).json({ error: 'Record is referenced by other data' });
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
}
