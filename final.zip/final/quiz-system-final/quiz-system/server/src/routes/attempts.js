import { Router } from 'express';
import { z } from 'zod';
import { query, withTransaction } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { validId } from '../middleware/validId.js';
import { asyncHandler, HttpError, pageParams, paged } from '../utils/http.js';
import { GRACE_SECONDS, getAttempt, finalizeAttempt, autoSubmit, saveAnswers, getResult } from '../services/attempts.js';

const router = Router();
router.use(authenticate);

const option = z.enum(['A', 'B', 'C', 'D']);
const answerSchema = z.object({ question_id: z.number().int().positive(), selected_option: option });
const submitSchema = z.object({ answers: z.array(answerSchema).max(500).default([]) });

// Start a quiz or resume an in-progress attempt. Correct answers are never sent.
router.post('/start', requireRole('student'), validate(z.object({ quiz_id: z.number().int().positive() })),
  asyncHandler(async (req, res) => {
    const { quiz_id } = req.body;
    const quiz = (await query('SELECT id, is_published FROM quizzes WHERE id=$1', [quiz_id])).rows[0];
    if (!quiz || !quiz.is_published) throw new HttpError(404, 'Quiz not found or not available');

    // One attempt per student per quiz (unique constraint); double-clicks are safe
    await query(`INSERT INTO attempts (quiz_id, student_id) VALUES ($1,$2)
                 ON CONFLICT (quiz_id, student_id) DO NOTHING`, [quiz_id, req.user.id]);
    const attempt = await getAttempt({ query }, 'a.quiz_id=$1 AND a.student_id=$2', [quiz_id, req.user.id]);

    if (attempt.status === 'submitted') {
      throw new HttpError(409, 'You have already completed this quiz', { attempt_id: attempt.id });
    }
    if (attempt.remaining_seconds <= 0) {
      await autoSubmit(attempt.id);
      throw new HttpError(409, 'Time expired; your attempt was submitted automatically', { attempt_id: attempt.id });
    }
    const [questions, answers] = await Promise.all([
      query(`SELECT id, text, option_a, option_b, option_c, option_d, marks
             FROM questions WHERE quiz_id=$1 ORDER BY id`, [quiz_id]),
      query('SELECT question_id, selected_option FROM answers WHERE attempt_id=$1', [attempt.id]),
    ]);
    res.json({
      attempt_id: attempt.id,
      quiz: { id: quiz_id, title: attempt.title, duration_minutes: attempt.duration_minutes },
      remaining_seconds: attempt.remaining_seconds,
      questions: questions.rows,
      saved_answers: answers.rows,
    });
  }));

// Student's own attempt history
router.get('/mine', requireRole('student'), asyncHandler(async (req, res) => {
  const p = pageParams(req.query);
  const [list, count] = await Promise.all([
    query(`SELECT a.id, q.title AS quiz, a.score, a.total_marks, a.submitted_at,
                  ROUND(100.0 * a.score / NULLIF(a.total_marks, 0), 1)::float8 AS percent,
                  (a.score >= q.pass_marks) AS passed
           FROM attempts a JOIN quizzes q ON q.id = a.quiz_id
           WHERE a.student_id = $1 AND a.status = 'submitted'
           ORDER BY a.submitted_at DESC LIMIT $2 OFFSET $3`, [req.user.id, p.limit, p.offset]),
    query("SELECT COUNT(*)::int AS total FROM attempts WHERE student_id=$1 AND status='submitted'", [req.user.id]),
  ]);
  res.json(paged(list.rows, count.rows[0].total, p));
}));

// Save one answer while the timer is running
router.put('/:id/answer', validId('id'), requireRole('student'), validate(answerSchema), asyncHandler(async (req, res) => {
  const attempt = await getAttempt({ query }, 'a.id=$1 AND a.student_id=$2', [req.params.id, req.user.id]);
  if (!attempt) throw new HttpError(404, 'Attempt not found');
  if (attempt.status === 'submitted') throw new HttpError(409, 'Attempt already submitted');
  if (attempt.remaining_seconds <= 0) {
    await autoSubmit(attempt.id);
    throw new HttpError(409, 'Time is up; your attempt was submitted automatically', { attempt_id: attempt.id });
  }
  const { rowCount } = await query(
    `INSERT INTO answers (attempt_id, question_id, selected_option)
     SELECT $1, q.id, $3 FROM questions q WHERE q.id=$2 AND q.quiz_id=$4
     ON CONFLICT (attempt_id, question_id) DO UPDATE SET selected_option = EXCLUDED.selected_option`,
    [attempt.id, req.body.question_id, req.body.selected_option, attempt.quiz_id]);
  if (!rowCount) throw new HttpError(400, 'Question does not belong to this quiz');
  res.json({ saved: true });
}));

// Submit and grade. Safe to call twice (returns the same result).
// Final answers in the body are accepted only within the time limit plus a short grace period.
router.post('/:id/submit', validId('id'), requireRole('student'), validate(submitSchema), asyncHandler(async (req, res) => {
  const id = await withTransaction(async (c) => {
    const attempt = await getAttempt(c, 'a.id=$1 AND a.student_id=$2', [req.params.id, req.user.id], true);
    if (!attempt) throw new HttpError(404, 'Attempt not found');
    if (attempt.status === 'in_progress') {
      if (attempt.remaining_seconds > -GRACE_SECONDS) await saveAnswers(c, attempt, req.body.answers);
      await finalizeAttempt(c, attempt.id);
    }
    return attempt.id;
  });
  res.json(await getResult(id));
}));

// Result with review. Students can only see their own; teachers can see any.
router.get('/:id/result', validId('id'), asyncHandler(async (req, res) => {
  const result = await getResult(req.params.id);
  if (!result || (req.user.role === 'student' && result.student_id !== req.user.id)) {
    throw new HttpError(404, 'Result not found');
  }
  res.json(result);
}));

export default router;
