import { Router } from 'express';
import { stringify } from 'csv-stringify/sync';
import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { asyncHandler, HttpError, pageParams, paged, searchClause } from '../utils/http.js';
import { csvSafe } from '../utils/csv.js';

const router = Router();
router.use(authenticate, requireRole('teacher'));

const FROM = `FROM attempts a JOIN users u ON u.id = a.student_id JOIN quizzes qz ON qz.id = a.quiz_id`;
const COLS = `a.id, u.name AS student, u.roll_no, u.email, qz.title AS quiz, a.score, a.total_marks,
  ROUND(100.0 * a.score / NULLIF(a.total_marks, 0), 1)::float8 AS percent,
  (a.score >= qz.pass_marks) AS passed, a.submitted_at`;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

// Builds the WHERE clause shared by the report list, summary and export
function buildFilters(q) {
  const where = ["a.status = 'submitted'"];
  const params = [];
  if (q.quiz_id !== undefined && q.quiz_id !== '') {
    const id = Number(q.quiz_id);
    if (!Number.isInteger(id) || id < 1) throw new HttpError(400, 'Invalid quiz_id');
    params.push(id);
    where.push(`a.quiz_id = $${params.length}`);
  }
  const s = searchClause(params, q.search, ['u.name', 'u.roll_no', 'u.email']);
  if (s) where.push(s);
  if (q.result === 'pass') where.push('a.score >= qz.pass_marks');
  else if (q.result === 'fail') where.push('a.score < qz.pass_marks');
  if (q.from) {
    if (!DATE.test(q.from)) throw new HttpError(400, 'from must be YYYY-MM-DD');
    params.push(q.from);
    where.push(`a.submitted_at >= $${params.length}::date`);
  }
  if (q.to) {
    if (!DATE.test(q.to)) throw new HttpError(400, 'to must be YYYY-MM-DD');
    params.push(q.to);
    where.push(`a.submitted_at < ($${params.length}::date + 1)`);
  }
  return { w: where.join(' AND '), params };
}

const SORTS = { submitted_at: 'a.submitted_at', score: 'a.score', percent: 'percent', name: 'u.name' };
const orderBy = (q) => `ORDER BY ${SORTS[q.sort] || 'a.submitted_at'} ${q.order === 'asc' ? 'ASC' : 'DESC'}, a.id`;

router.get('/results', asyncHandler(async (req, res) => {
  const p = pageParams(req.query);
  const { w, params } = buildFilters(req.query);
  const [list, summary] = await Promise.all([
    query(`SELECT ${COLS} ${FROM} WHERE ${w} ${orderBy(req.query)}
           LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, p.limit, p.offset]),
    query(`SELECT COUNT(*)::int AS attempts,
                  ROUND(AVG(100.0 * a.score / NULLIF(a.total_marks, 0)), 1)::float8 AS avg_percent,
                  ROUND(100.0 * AVG((a.score >= qz.pass_marks)::int), 1)::float8 AS pass_rate
           ${FROM} WHERE ${w}`, params),
  ]);
  const body = paged(list.rows, summary.rows[0].attempts, p);
  body.summary = summary.rows[0];
  res.json(body);
}));

// CSV export using the same filters (no pagination, capped at 50,000 rows)
router.get('/results/export', asyncHandler(async (req, res) => {
  const { w, params } = buildFilters(req.query);
  const { rows } = await query(`SELECT ${COLS} ${FROM} WHERE ${w} ${orderBy(req.query)} LIMIT 50000`, params);
  const csv = stringify(rows.map((r) => ({
    Student: csvSafe(r.student), 'Roll No': csvSafe(r.roll_no), Email: csvSafe(r.email), Quiz: csvSafe(r.quiz),
    Score: r.score, 'Total Marks': r.total_marks, Percent: r.percent,
    Result: r.passed ? 'Pass' : 'Fail', 'Submitted At': r.submitted_at.toISOString(),
  })), { header: true });
  res.set({
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="results-${new Date().toISOString().slice(0, 10)}.csv"`,
  });
  res.send('\ufeff' + csv); // BOM so Excel reads UTF-8 correctly
}));

export default router;
