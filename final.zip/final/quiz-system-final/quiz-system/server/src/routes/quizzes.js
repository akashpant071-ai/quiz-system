import { Router } from 'express';
import { z } from 'zod';
import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { validId } from '../middleware/validId.js';
import { asyncHandler, HttpError, pageParams, paged, searchClause } from '../utils/http.js';

const router = Router();
router.use(authenticate);

const quizSchema = z.object({
  title: z.string().trim().min(3).max(150),
  description: z.string().trim().max(1000).nullish().transform((v) => v || null),
  duration_minutes: z.number().int().min(1).max(300),
  pass_marks: z.number().int().min(0).max(10000),
});

const STATS = `
  (SELECT COUNT(*) FROM questions x WHERE x.quiz_id = q.id)::int AS question_count,
  (SELECT COALESCE(SUM(x.marks),0) FROM questions x WHERE x.quiz_id = q.id)::int AS total_marks`;

// Teachers see all quizzes; students see published quizzes with their own attempt status
router.get('/', asyncHandler(async (req, res) => {
  const p = pageParams(req.query);
  const isStudent = req.user.role === 'student';
  const params = [];
  const where = [];
  if (isStudent) where.push('q.is_published');
  const s = searchClause(params, req.query.search, ['q.title']);
  if (s) where.push(s);
  if (!isStudent && ['true', 'false'].includes(req.query.published)) {
    where.push(`q.is_published = ${req.query.published}`); // whitelisted literal
  }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const extra = isStudent
    ? ', a.id AS attempt_id, a.status AS attempt_status'
    : `, q.is_published, (SELECT COUNT(*) FROM attempts x WHERE x.quiz_id = q.id AND x.status = 'submitted')::int AS attempt_count`;
  const join = isStudent ? `LEFT JOIN attempts a ON a.quiz_id = q.id AND a.student_id = ${Number(req.user.id)}` : '';

  const [list, count] = await Promise.all([
    query(`SELECT q.id,q.title,q.description,q.duration_minutes,q.pass_marks,q.created_at,${STATS}${extra}
           FROM quizzes q ${join} ${w}
           ORDER BY q.created_at DESC, q.id DESC
           LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, p.limit, p.offset]),
    query(`SELECT COUNT(*)::int AS total FROM quizzes q ${w}`, params),
  ]);
  res.json(paged(list.rows, count.rows[0].total, p));
}));

const teacherOnly = [requireRole('teacher')];

router.get('/:id', validId('id'), ...teacherOnly, asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT q.*, ${STATS} FROM quizzes q WHERE q.id = $1`, [req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Quiz not found');
  res.json(rows[0]);
}));

router.post('/', ...teacherOnly, validate(quizSchema), asyncHandler(async (req, res) => {
  const { title, description, duration_minutes, pass_marks } = req.body;
  const { rows } = await query(
    `INSERT INTO quizzes (title,description,duration_minutes,pass_marks,created_by)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [title, description, duration_minutes, pass_marks, req.user.id]);
  res.status(201).json(rows[0]);
}));

router.put('/:id', validId('id'), ...teacherOnly, validate(quizSchema), asyncHandler(async (req, res) => {
  const { title, description, duration_minutes, pass_marks } = req.body;
  const { rows } = await query(
    `UPDATE quizzes SET title=$1, description=$2, duration_minutes=$3, pass_marks=$4
     WHERE id=$5 RETURNING *`,
    [title, description, duration_minutes, pass_marks, req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Quiz not found');
  res.json(rows[0]);
}));

// Publish / unpublish. A quiz needs questions and achievable pass marks before publishing.
router.patch('/:id/publish', validId('id'), ...teacherOnly,
  validate(z.object({ is_published: z.boolean() })),
  asyncHandler(async (req, res) => {
    const { rows } = await query(`SELECT q.pass_marks, ${STATS} FROM quizzes q WHERE q.id = $1`, [req.params.id]);
    const quiz = rows[0];
    if (!quiz) throw new HttpError(404, 'Quiz not found');
    if (req.body.is_published) {
      if (quiz.question_count === 0) throw new HttpError(400, 'Add at least one question before publishing');
      if (quiz.pass_marks > quiz.total_marks) {
        throw new HttpError(400, `Pass marks (${quiz.pass_marks}) exceed total marks (${quiz.total_marks})`);
      }
    }
    const updated = await query('UPDATE quizzes SET is_published=$1 WHERE id=$2 RETURNING id,is_published',
      [req.body.is_published, req.params.id]);
    res.json(updated.rows[0]);
  }));

// Deleting a quiz also deletes its questions, attempts and answers (ON DELETE CASCADE)
router.delete('/:id', validId('id'), ...teacherOnly, asyncHandler(async (req, res) => {
  const { rowCount } = await query('DELETE FROM quizzes WHERE id=$1', [req.params.id]);
  if (!rowCount) throw new HttpError(404, 'Quiz not found');
  res.status(204).end();
}));

export default router;
