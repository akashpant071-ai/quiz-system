import { Router } from 'express';
import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../utils/http.js';

const router = Router();

// All figures come from live database queries
router.get('/', authenticate, requireRole('teacher'), asyncHandler(async (_req, res) => {
  const [totals, recent, perQuiz] = await Promise.all([
    query(`SELECT
             (SELECT COUNT(*) FROM users WHERE role = 'student')::int AS students,
             (SELECT COUNT(*) FROM quizzes)::int AS quizzes,
             (SELECT COUNT(*) FROM quizzes WHERE is_published)::int AS published_quizzes,
             (SELECT COUNT(*) FROM questions)::int AS questions,
             COUNT(*)::int AS attempts,
             ROUND(AVG(100.0 * a.score / NULLIF(a.total_marks, 0)), 1)::float8 AS avg_percent,
             ROUND(100.0 * AVG((a.score >= q.pass_marks)::int), 1)::float8 AS pass_rate
           FROM attempts a JOIN quizzes q ON q.id = a.quiz_id WHERE a.status = 'submitted'`),
    query(`SELECT a.id, u.name AS student, q.title AS quiz, a.score, a.total_marks, a.submitted_at,
                  (a.score >= q.pass_marks) AS passed
           FROM attempts a JOIN users u ON u.id = a.student_id JOIN quizzes q ON q.id = a.quiz_id
           WHERE a.status = 'submitted' ORDER BY a.submitted_at DESC LIMIT 5`),
    query(`SELECT q.id, q.title, COUNT(a.id)::int AS attempts,
                  ROUND(AVG(100.0 * a.score / NULLIF(a.total_marks, 0)), 1)::float8 AS avg_percent,
                  ROUND(100.0 * AVG((a.score >= q.pass_marks)::int), 1)::float8 AS pass_rate
           FROM quizzes q JOIN attempts a ON a.quiz_id = q.id AND a.status = 'submitted'
           GROUP BY q.id ORDER BY attempts DESC LIMIT 5`),
  ]);
  res.json({ totals: totals.rows[0], recent_attempts: recent.rows, quiz_stats: perQuiz.rows });
}));

export default router;
