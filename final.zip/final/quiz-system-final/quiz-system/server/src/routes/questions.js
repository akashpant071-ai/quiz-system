import { Router } from 'express';
import { z } from 'zod';
import { query, withTransaction } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { validId } from '../middleware/validId.js';
import { csvUpload } from '../middleware/upload.js';
import { asyncHandler, HttpError, pageParams, paged, searchClause } from '../utils/http.js';
import { readCsv } from '../utils/csv.js';

// Mounted at /api, so auth is applied per route (not router.use)
const router = Router();
const teacherOnly = [authenticate, requireRole('teacher')];

const option = z.string().trim().min(1).max(255);
const questionSchema = z.object({
  text: z.string().trim().min(3).max(1000),
  option_a: option,
  option_b: option,
  option_c: option,
  option_d: option,
  correct_option: z.string().trim().toUpperCase().pipe(z.enum(['A', 'B', 'C', 'D'])),
  marks: z.coerce.number().int().min(1).max(100).default(1),
});

const COLUMNS = 'id,quiz_id,text,option_a,option_b,option_c,option_d,correct_option,marks';

async function assertQuizExists(quizId) {
  const { rowCount } = await query('SELECT 1 FROM quizzes WHERE id=$1', [quizId]);
  if (!rowCount) throw new HttpError(404, 'Quiz not found');
}

// Questions are locked once students have attempted the quiz, so past results stay correct
async function assertEditable(quizId) {
  await assertQuizExists(quizId);
  const { rowCount } = await query('SELECT 1 FROM attempts WHERE quiz_id=$1 LIMIT 1', [quizId]);
  if (rowCount) throw new HttpError(409, 'Questions cannot be changed after students have attempted this quiz');
}

router.get('/quizzes/:quizId/questions', validId('quizId'), ...teacherOnly, asyncHandler(async (req, res) => {
  await assertQuizExists(req.params.quizId);
  const p = pageParams(req.query);
  const params = [req.params.quizId];
  const where = ['quiz_id = $1'];
  const s = searchClause(params, req.query.search, ['text']);
  if (s) where.push(s);
  const w = where.join(' AND ');
  const [list, count] = await Promise.all([
    query(`SELECT ${COLUMNS} FROM questions WHERE ${w} ORDER BY id
           LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, p.limit, p.offset]),
    query(`SELECT COUNT(*)::int AS total FROM questions WHERE ${w}`, params),
  ]);
  res.json(paged(list.rows, count.rows[0].total, p));
}));

router.post('/quizzes/:quizId/questions', validId('quizId'), ...teacherOnly, validate(questionSchema),
  asyncHandler(async (req, res) => {
    await assertEditable(req.params.quizId);
    const q = req.body;
    const { rows } = await query(
      `INSERT INTO questions (quiz_id,text,option_a,option_b,option_c,option_d,correct_option,marks)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING ${COLUMNS}`,
      [req.params.quizId, q.text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option, q.marks]);
    res.status(201).json(rows[0]);
  }));

// CSV import. Columns: question, option_a, option_b, option_c, option_d, correct_option, marks (optional)
router.post('/quizzes/:quizId/questions/import', validId('quizId'), ...teacherOnly, csvUpload,
  asyncHandler(async (req, res) => {
    await assertEditable(req.params.quizId);
    const records = readCsv(req.file, ['question', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option']);
    const failed = [];
    const valid = [];
    records.forEach((rec, idx) => {
      const row = idx + 2;
      const parsed = questionSchema.safeParse({
        text: rec.question, option_a: rec.option_a, option_b: rec.option_b, option_c: rec.option_c,
        option_d: rec.option_d, correct_option: rec.correct_option,
        marks: rec.marks === '' || rec.marks === undefined ? undefined : rec.marks,
      });
      if (parsed.success) valid.push(parsed.data);
      else failed.push({ row, errors: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) });
    });

    if (valid.length) {
      const col = (key) => valid.map((v) => v[key]);
      await withTransaction((c) => c.query(
        `INSERT INTO questions (quiz_id,text,option_a,option_b,option_c,option_d,correct_option,marks)
         SELECT $1, t.*
         FROM unnest($2::text[],$3::text[],$4::text[],$5::text[],$6::text[],$7::text[],$8::int[]) AS t`,
        [req.params.quizId, col('text'), col('option_a'), col('option_b'), col('option_c'),
         col('option_d'), col('correct_option'), col('marks')]));
    }
    res.status(valid.length ? 201 : 200).json({ imported: valid.length, failed });
  }));

router.put('/questions/:id', validId('id'), ...teacherOnly, validate(questionSchema), asyncHandler(async (req, res) => {
  const found = await query('SELECT quiz_id FROM questions WHERE id=$1', [req.params.id]);
  if (!found.rows[0]) throw new HttpError(404, 'Question not found');
  await assertEditable(found.rows[0].quiz_id);
  const q = req.body;
  const { rows } = await query(
    `UPDATE questions SET text=$1,option_a=$2,option_b=$3,option_c=$4,option_d=$5,correct_option=$6,marks=$7
     WHERE id=$8 RETURNING ${COLUMNS}`,
    [q.text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option, q.marks, req.params.id]);
  res.json(rows[0]);
}));

router.delete('/questions/:id', validId('id'), ...teacherOnly, asyncHandler(async (req, res) => {
  const found = await query('SELECT quiz_id FROM questions WHERE id=$1', [req.params.id]);
  if (!found.rows[0]) throw new HttpError(404, 'Question not found');
  await assertEditable(found.rows[0].quiz_id);
  await query('DELETE FROM questions WHERE id=$1', [req.params.id]);
  res.status(204).end();
}));

export default router;
