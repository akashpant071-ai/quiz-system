import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query, withTransaction } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { validId } from '../middleware/validId.js';
import { csvUpload } from '../middleware/upload.js';
import { asyncHandler, HttpError, pageParams, paged, searchClause } from '../utils/http.js';
import { readCsv } from '../utils/csv.js';

const router = Router();
router.use(authenticate, requireRole('teacher'));

const DEFAULT_PASSWORD = 'Student@123'; // used for CSV rows without a password column value

const name = z.string().trim().min(2).max(100);
const email = z.string().trim().toLowerCase().email().max(150);
const rollNo = z.string().trim().min(1).max(30);
const password = z.string().min(8, 'at least 8 characters').max(72);

const createSchema = z.object({ name, email, roll_no: rollNo, password });
const updateSchema = z.object({ name, email, roll_no: rollNo, password: password.optional() });
const importSchema = z.object({ name, email, roll_no: rollNo, password: password.optional() });

const COLUMNS = 'id,name,email,roll_no,created_at';

// List with search, sorting and pagination
router.get('/', asyncHandler(async (req, res) => {
  const p = pageParams(req.query);
  const params = [];
  const where = ["role = 'student'"];
  const s = searchClause(params, req.query.search, ['name', 'email', 'roll_no']);
  if (s) where.push(s);
  const sortable = { name: 'name', roll_no: 'roll_no', created_at: 'created_at' };
  const col = sortable[req.query.sort] || 'created_at';
  const dir = req.query.order === 'asc' ? 'ASC' : 'DESC';
  const w = where.join(' AND ');

  const [list, count] = await Promise.all([
    query(`SELECT ${COLUMNS} FROM users WHERE ${w} ORDER BY ${col} ${dir}, id
           LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, p.limit, p.offset]),
    query(`SELECT COUNT(*)::int AS total FROM users WHERE ${w}`, params),
  ]);
  res.json(paged(list.rows, count.rows[0].total, p));
}));

router.get('/:id', validId('id'), asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT ${COLUMNS} FROM users WHERE id = $1 AND role = 'student'`, [req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Student not found');
  res.json(rows[0]);
}));

router.post('/', validate(createSchema), asyncHandler(async (req, res) => {
  const { name, email, roll_no, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const { rows } = await query(
    `INSERT INTO users (name,email,password_hash,role,roll_no) VALUES ($1,$2,$3,'student',$4) RETURNING ${COLUMNS}`,
    [name, email, hash, roll_no]);
  res.status(201).json(rows[0]);
}));

router.put('/:id', validId('id'), validate(updateSchema), asyncHandler(async (req, res) => {
  const { name, email, roll_no, password } = req.body;
  const hash = password ? await bcrypt.hash(password, 10) : null;
  const { rows } = await query(
    `UPDATE users SET name=$1, email=$2, roll_no=$3, password_hash = COALESCE($4, password_hash)
     WHERE id=$5 AND role='student' RETURNING ${COLUMNS}`,
    [name, email, roll_no, hash, req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Student not found');
  res.json(rows[0]);
}));

// Deleting a student also deletes their attempts and answers (ON DELETE CASCADE)
router.delete('/:id', validId('id'), asyncHandler(async (req, res) => {
  const { rowCount } = await query("DELETE FROM users WHERE id=$1 AND role='student'", [req.params.id]);
  if (!rowCount) throw new HttpError(404, 'Student not found');
  res.status(204).end();
}));

// CSV import. Columns: name, email, roll_no, password (optional)
router.post('/import', csvUpload, asyncHandler(async (req, res) => {
  const records = readCsv(req.file, ['name', 'email', 'roll_no']);
  const failed = [];
  const valid = [];
  const seenEmail = new Set();
  const seenRoll = new Set();

  records.forEach((rec, idx) => {
    const row = idx + 2; // row 1 is the header
    const parsed = importSchema.safeParse({
      name: rec.name, email: rec.email, roll_no: rec.roll_no, password: rec.password || undefined,
    });
    if (!parsed.success) {
      failed.push({ row, errors: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) });
      return;
    }
    const d = parsed.data;
    const errors = [];
    if (seenEmail.has(d.email)) errors.push('email: duplicate within file');
    if (seenRoll.has(d.roll_no)) errors.push('roll_no: duplicate within file');
    if (errors.length) { failed.push({ row, errors }); return; }
    seenEmail.add(d.email);
    seenRoll.add(d.roll_no);
    valid.push({ row, ...d });
  });

  // Reject rows whose email or roll number already exist in the database
  let toInsert = valid;
  if (valid.length) {
    const existing = await query(
      'SELECT email, roll_no FROM users WHERE email = ANY($1) OR roll_no = ANY($2)',
      [valid.map((v) => v.email), valid.map((v) => v.roll_no)]);
    const emails = new Set(existing.rows.map((r) => r.email));
    const rolls = new Set(existing.rows.map((r) => r.roll_no));
    toInsert = [];
    for (const v of valid) {
      const errors = [];
      if (emails.has(v.email)) errors.push('email: already exists');
      if (rolls.has(v.roll_no)) errors.push('roll_no: already exists');
      if (errors.length) failed.push({ row: v.row, errors }); else toInsert.push(v);
    }
  }

  let defaultPasswordUsed = 0;
  if (toInsert.length) {
    const defaultHash = await bcrypt.hash(DEFAULT_PASSWORD, 10);
    const hashes = [];
    for (const v of toInsert) {
      if (v.password) hashes.push(await bcrypt.hash(v.password, 10));
      else { hashes.push(defaultHash); defaultPasswordUsed++; }
    }
    await withTransaction((c) => c.query(
      `INSERT INTO users (name,email,password_hash,role,roll_no)
       SELECT n, e, h, 'student', r
       FROM unnest($1::text[], $2::text[], $3::text[], $4::text[]) AS t(n, e, h, r)`,
      [toInsert.map((v) => v.name), toInsert.map((v) => v.email), hashes, toInsert.map((v) => v.roll_no)]));
  }

  failed.sort((a, b) => a.row - b.row);
  res.status(toInsert.length ? 201 : 200).json({
    imported: toInsert.length,
    failed,
    note: defaultPasswordUsed ? `${defaultPasswordUsed} student(s) got the default password ${DEFAULT_PASSWORD}` : undefined,
  });
}));

export default router;
