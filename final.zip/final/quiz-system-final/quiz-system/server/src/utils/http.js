export class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

// Lets async route handlers throw; errors reach the central error handler
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export function pageParams(q) {
  const page = Math.max(1, parseInt(q.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(q.limit, 10) || 10));
  return { page, limit, offset: (page - 1) * limit };
}

export const paged = (rows, total, { page, limit }) => ({
  data: rows,
  pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
});

// Escape LIKE wildcards so user input is matched literally
export const escapeLike = (s) => s.replace(/[\\%_]/g, '\\$&');

// Adds a case-insensitive partial-match clause over several columns.
// Pushes the search term into params and returns the SQL fragment (or null).
export function searchClause(params, term, columns) {
  const t = String(term ?? '').trim().slice(0, 100);
  if (!t) return null;
  params.push(escapeLike(t));
  const i = params.length;
  return '(' + columns.map((c) => `${c} ILIKE '%'||$${i}||'%'`).join(' OR ') + ')';
}
