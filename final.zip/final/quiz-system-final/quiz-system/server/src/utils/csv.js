import { parse } from 'csv-parse/sync';
import { HttpError } from './http.js';

export const MAX_IMPORT_ROWS = 500;

// Reads an uploaded CSV (multer memory file) into an array of objects.
// Header names are lower-cased and trimmed.
export function readCsv(file, requiredColumns) {
  if (!file) throw new HttpError(400, 'CSV file is required (form field name: file)');
  let rows;
  try {
    rows = parse(file.buffer, {
      columns: (header) => header.map((h) => String(h).trim().toLowerCase()),
      bom: true,
      skip_empty_lines: true,
      trim: true,
    });
  } catch (err) {
    throw new HttpError(400, `Could not read CSV: ${err.message}`);
  }
  if (rows.length === 0) throw new HttpError(400, 'CSV has no data rows');
  if (rows.length > MAX_IMPORT_ROWS) {
    throw new HttpError(400, `CSV has too many rows (max ${MAX_IMPORT_ROWS} per upload)`);
  }
  const missing = requiredColumns.filter((c) => !(c in rows[0]));
  if (missing.length) throw new HttpError(400, `Missing required column(s): ${missing.join(', ')}`);
  return rows;
}

// Prevents spreadsheet formula injection in exported CSV files
export const csvSafe = (v) => (typeof v === 'string' && /^[=+\-@\t\r]/.test(v) ? `'${v}` : v);
