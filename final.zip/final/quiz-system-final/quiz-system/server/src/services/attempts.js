import { query, withTransaction } from '../config/db.js';

// Extra seconds allowed for the final submit request (network delay after the timer hits zero)
export const GRACE_SECONDS = 10;

const ATTEMPT_SQL = `
  SELECT a.id, a.quiz_id, a.student_id, a.status, a.started_at,
         q.title, q.duration_minutes, q.pass_marks,
         FLOOR(EXTRACT(EPOCH FROM (a.started_at + q.duration_minutes * INTERVAL '1 minute' - now())))::int AS remaining_seconds
  FROM attempts a JOIN quizzes q ON q.id = a.quiz_id`;

export async function getAttempt(db, where, params, lock = false) {
  const { rows } = await db.query(`${ATTEMPT_SQL} WHERE ${where}${lock ? ' FOR UPDATE OF a' : ''}`, params);
  return rows[0];
}

// Server-side grading: marks each answer, then stores score and total. Must run inside a transaction.
export async function finalizeAttempt(db, attemptId) {
  await db.query(
    `UPDATE answers an SET is_correct = (an.selected_option = q.correct_option)
     FROM questions q WHERE an.attempt_id = $1 AND an.question_id = q.id`, [attemptId]);
  await db.query(
    `UPDATE attempts SET status = 'submitted', submitted_at = now(),
       score = (SELECT COALESCE(SUM(q.marks), 0) FROM answers an JOIN questions q ON q.id = an.question_id
                WHERE an.attempt_id = attempts.id AND an.is_correct),
       total_marks = (SELECT COALESCE(SUM(marks), 0) FROM questions WHERE quiz_id = attempts.quiz_id)
     WHERE id = $1`, [attemptId]);
}

// Submits an expired in-progress attempt using whatever answers were saved
export const autoSubmit = (attemptId) => withTransaction(async (c) => {
  const a = await getAttempt(c, 'a.id = $1', [attemptId], true);
  if (a && a.status === 'in_progress') await finalizeAttempt(c, attemptId);
});

export async function saveAnswers(db, attempt, answers) {
  const latest = new Map(answers.map((a) => [a.question_id, a.selected_option])); // last answer wins
  if (!latest.size) return;
  await db.query(
    `INSERT INTO answers (attempt_id, question_id, selected_option)
     SELECT $1, q.id, t.opt
     FROM unnest($2::int[], $3::text[]) AS t(qid, opt)
     JOIN questions q ON q.id = t.qid AND q.quiz_id = $4
     ON CONFLICT (attempt_id, question_id) DO UPDATE SET selected_option = EXCLUDED.selected_option`,
    [attempt.id, [...latest.keys()], [...latest.values()], attempt.quiz_id]);
}

// Result summary plus per-question review for a submitted attempt
export async function getResult(attemptId) {
  const head = await query(
    `SELECT a.id, a.student_id, a.score, a.total_marks, a.started_at, a.submitted_at,
            q.title AS quiz, q.pass_marks, u.name AS student, u.roll_no,
            ROUND(100.0 * a.score / NULLIF(a.total_marks, 0), 1)::float8 AS percent,
            (a.score >= q.pass_marks) AS passed
     FROM attempts a JOIN quizzes q ON q.id = a.quiz_id JOIN users u ON u.id = a.student_id
     WHERE a.id = $1 AND a.status = 'submitted'`, [attemptId]);
  if (!head.rows[0]) return null;
  const review = await query(
    `SELECT qu.id AS question_id, qu.text, qu.option_a, qu.option_b, qu.option_c, qu.option_d,
            qu.correct_option, qu.marks, an.selected_option, COALESCE(an.is_correct, false) AS is_correct
     FROM attempts a JOIN questions qu ON qu.quiz_id = a.quiz_id
     LEFT JOIN answers an ON an.attempt_id = a.id AND an.question_id = qu.id
     WHERE a.id = $1 ORDER BY qu.id`, [attemptId]);
  return { ...head.rows[0], review: review.rows };
}
