import 'dotenv/config';
import pg from 'pg';
import { dbSsl } from './ssl.js';

export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: dbSsl });
export const query = (text, params) => pool.query(text, params);

// Runs fn(client) inside a transaction; rolls back on any error
export async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}
