// Supabase (and most hosted databases) need SSL. It is switched on automatically
// when DATABASE_URL points to supabase, or when DB_SSL=true is set in .env.
const url = process.env.DATABASE_URL || '';
export const dbSsl = process.env.DB_SSL === 'true' || /supabase\./i.test(url)
  ? { rejectUnauthorized: false }
  : false;
