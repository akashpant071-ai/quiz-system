import 'dotenv/config';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import { dbSsl } from '../src/config/ssl.js';

const client = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: dbSsl });

const questions = [
  ['What does TQM stand for?', 'Total Quality Management', 'Total Quantity Method', 'Technical Quality Model', 'Total Query Management', 'A'],
  ['Who is known for popularising the PDCA cycle?', 'Philip Crosby', 'W. Edwards Deming', 'Joseph Juran', 'Kaoru Ishikawa', 'B'],
  ['A fishbone diagram is used for?', 'Scheduling', 'Cost estimation', 'Root cause analysis', 'Sorting data', 'C'],
  ['Six Sigma aims at roughly how many defects per million opportunities?', '3.4', '34', '340', '3400', 'A'],
  ['In PDCA, what does "C" stand for?', 'Create', 'Check', 'Control', 'Complete', 'B'],
];

try {
  await client.connect();
  await client.query('BEGIN');

  const teacherHash = await bcrypt.hash('Teacher@123', 10);
  const studentHash = await bcrypt.hash('Student@123', 10);

  const t = await client.query(
    `INSERT INTO users (name,email,password_hash,role)
     VALUES ('Demo Teacher','teacher@quiz.local',$1,'teacher')
     ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name RETURNING id`, [teacherHash]);
  const teacherId = t.rows[0].id;

  for (let i = 1; i <= 5; i++) {
    await client.query(
      `INSERT INTO users (name,email,password_hash,role,roll_no)
       VALUES ($1,$2,$3,'student',$4) ON CONFLICT (email) DO NOTHING`,
      [`Student ${i}`, `student${i}@quiz.local`, studentHash, `ROLL00${i}`]);
  }

  const exists = await client.query(`SELECT id FROM quizzes WHERE title = 'TQM Basics'`);
  if (exists.rowCount === 0) {
    const q = await client.query(
      `INSERT INTO quizzes (title,description,duration_minutes,pass_marks,is_published,created_by)
       VALUES ('TQM Basics','Introductory quiz on Total Quality Management',10,3,TRUE,$1) RETURNING id`,
      [teacherId]);
    for (const row of questions) {
      await client.query(
        `INSERT INTO questions (quiz_id,text,option_a,option_b,option_c,option_d,correct_option,marks)
         VALUES ($1,$2,$3,$4,$5,$6,$7,1)`, [q.rows[0].id, ...row]);
    }
  }

  await client.query('COMMIT');
  console.log('Seed data inserted.');
} catch (err) {
  await client.query('ROLLBACK').catch(() => {});
  console.error('Seeding failed:', err.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
