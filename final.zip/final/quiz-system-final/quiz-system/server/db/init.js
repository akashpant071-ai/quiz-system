import 'dotenv/config';
import fs from 'node:fs';
import pg from 'pg';
import { dbSsl } from '../src/config/ssl.js';

const client = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: dbSsl });
try {
  await client.connect();
  await client.query(fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
  console.log('Schema created.');
} catch (err) {
  console.error('Schema creation failed:', err.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
