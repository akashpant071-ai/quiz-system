CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role          VARCHAR(10)  NOT NULL CHECK (role IN ('teacher','student')),
  roll_no       VARCHAR(30)  UNIQUE,
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quizzes (
  id               SERIAL PRIMARY KEY,
  title            VARCHAR(150) NOT NULL,
  description      TEXT,
  duration_minutes INT NOT NULL CHECK (duration_minutes BETWEEN 1 AND 300),
  pass_marks       INT NOT NULL DEFAULT 0 CHECK (pass_marks >= 0),
  is_published     BOOLEAN NOT NULL DEFAULT FALSE,
  created_by       INT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS questions (
  id             SERIAL PRIMARY KEY,
  quiz_id        INT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  text           TEXT NOT NULL,
  option_a       VARCHAR(255) NOT NULL,
  option_b       VARCHAR(255) NOT NULL,
  option_c       VARCHAR(255) NOT NULL,
  option_d       VARCHAR(255) NOT NULL,
  correct_option CHAR(1) NOT NULL CHECK (correct_option IN ('A','B','C','D')),
  marks          INT NOT NULL DEFAULT 1 CHECK (marks > 0)
);

CREATE TABLE IF NOT EXISTS attempts (
  id           SERIAL PRIMARY KEY,
  quiz_id      INT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  student_id   INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  submitted_at TIMESTAMPTZ,
  score        INT,
  total_marks  INT,
  status       VARCHAR(12) NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted')),
  UNIQUE (quiz_id, student_id)
);

CREATE TABLE IF NOT EXISTS answers (
  attempt_id      INT NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,
  question_id     INT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  selected_option CHAR(1) CHECK (selected_option IN ('A','B','C','D')),
  is_correct      BOOLEAN,
  PRIMARY KEY (attempt_id, question_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_users_role          ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_name_trgm     ON users USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_quizzes_published   ON quizzes(is_published);
CREATE INDEX IF NOT EXISTS idx_quizzes_title_trgm  ON quizzes USING gin (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_questions_quiz      ON questions(quiz_id);
CREATE INDEX IF NOT EXISTS idx_attempts_quiz       ON attempts(quiz_id);
CREATE INDEX IF NOT EXISTS idx_attempts_student    ON attempts(student_id);
CREATE INDEX IF NOT EXISTS idx_attempts_submitted  ON attempts(submitted_at DESC);
