# API Reference

Base URL: `http://localhost:5000/api`. Send `Authorization: Bearer <token>` on every route except login and health.
Errors return `{ "error": "message", "details": [...] }`. List endpoints return `{ data, pagination: { page, limit, total, totalPages } }`.

| Method | Path | Role | Purpose |
|--------|------|------|---------|
| GET | /health | any | Health check |
| POST | /auth/login | any | Login, returns token |
| GET | /auth/me | any | Current user |
| GET | /dashboard | teacher | Totals, recent attempts, per-quiz stats |
| GET | /students | teacher | List. Query: `search, sort (name/roll_no/created_at), order, page, limit` |
| POST | /students | teacher | Create |
| GET/PUT/DELETE | /students/:id | teacher | Read, update (password optional), delete |
| POST | /students/import | teacher | CSV upload (form field `file`) |
| GET | /quizzes | any | Teacher: all (`search, published`). Student: published only, with own attempt status |
| POST | /quizzes | teacher | Create |
| GET/PUT/DELETE | /quizzes/:id | teacher | Read, update, delete |
| PATCH | /quizzes/:id/publish | teacher | Body `{ "is_published": true }` |
| GET | /quizzes/:quizId/questions | teacher | List. Query: `search, page, limit` |
| POST | /quizzes/:quizId/questions | teacher | Create |
| POST | /quizzes/:quizId/questions/import | teacher | CSV upload |
| PUT/DELETE | /questions/:id | teacher | Update, delete (blocked once attempted) |
| POST | /attempts/start | student | Body `{ "quiz_id": 1 }`. Starts or resumes; returns questions without answers and `remaining_seconds` |
| PUT | /attempts/:id/answer | student | Save one answer |
| POST | /attempts/:id/submit | student | Submit and grade; optional final `answers` |
| GET | /attempts/mine | student | Own history |
| GET | /attempts/:id/result | student (own) / teacher | Score and per-question review |
| GET | /reports/results | teacher | Filters: `quiz_id, search, result (pass/fail), from, to, sort, order, page, limit`; includes summary |
| GET | /reports/results/export | teacher | Same filters, downloads CSV |

## CSV formats
Students: `name,email,roll_no,password` (password optional, default `Student@123`).
Questions: `question,option_a,option_b,option_c,option_d,correct_option,marks` (marks optional, default 1).
Maximum 500 rows and 1 MB per file. Invalid rows are reported as `{ row, errors }`; valid rows are still imported. Samples are in `docs/samples/`.

## Business rules
- One attempt per student per quiz (database constraint).
- Timer is enforced on the server. Expired attempts are auto-submitted with saved answers; the final submit accepts answers up to 10 seconds late.
- Correct answers are never sent during an attempt, only in the result after submission.
- Questions are locked once any student has attempted the quiz, so past results stay valid.
- A quiz can be published only if it has questions and pass marks do not exceed total marks.
