# Software Requirements Specification
## Online Quiz Management System (B.Tech TQM Project)

## 1. Problem Statement
Teachers conduct class quizzes on paper or in unstructured tools. This causes slow grading, calculation errors, no central record of results, and difficulty in analysing performance. Students get delayed feedback. There is no quick way to search records or export reports.

The system provides a web application where teachers create quizzes and manage students, and students attempt timed quizzes that are graded automatically with results stored centrally.

## 2. Quality Objectives (TQM)
| ID | Objective | Measure |
|----|-----------|---------|
| Q1 | Accuracy of grading | 100% of objective answers graded by the server; zero manual calculation |
| Q2 | Performance | List pages (search/filter/paginate) respond in under 500 ms for 10,000 records |
| Q3 | Reliability | Submitted attempts are never lost; auto-submit when timer expires |
| Q4 | Security | Passwords hashed (bcrypt); JWT auth; role checks on every protected route |
| Q5 | Data integrity | Input validated on server; foreign keys and constraints in DB |
| Q6 | Usability | A student can start a quiz within 3 clicks after login |
| Q7 | Timeliness | Result shown immediately after submission |
| Q8 | Maintainability | Modular code, documented API, setup in under 15 minutes |

## 3. Scope
**In scope:** authentication, role-based access, CRUD for quizzes/questions/students, CSV import for students and questions, timed MCQ quizzes, automatic grading, result reports, CSV export, dashboard statistics.

**Out of scope:** subjective/essay grading, proctoring, payment, native mobile apps, email notifications.

## 4. User Roles
| Role | Permissions |
|------|-------------|
| Teacher/Admin | Manage students, quizzes and questions; import/export CSV; view dashboard and all results |
| Student | View published quizzes, attempt each once, view own results |

## 5. Modules
1. Authentication and Authorization
2. Student Management (CRUD, CSV import)
3. Quiz Management (CRUD, publish/unpublish)
4. Question Management (CRUD, CSV import)
5. Quiz Attempt (timer, answer saving, submit)
6. Grading and Results
7. Reports and CSV Export
8. Dashboard

## 6. Functional Requirements
- FR1: Users log in with email and password; the system returns a JWT.
- FR2: Teacher creates, edits, deletes and lists students with search, filter and pagination.
- FR3: Teacher imports students/questions from CSV; invalid rows are reported with row number and reason, valid rows are saved.
- FR4: Teacher creates quizzes with title, duration, pass marks, and MCQ questions (4 options, one correct, marks).
- FR5: Student sees only published quizzes and can attempt each once.
- FR6: Timer runs during the attempt; on expiry the attempt is auto-submitted.
- FR7: Server grades the attempt and stores score, answers and pass/fail.
- FR8: Teacher views results per quiz with filters and exports CSV.
- FR9: Dashboard shows total students, quizzes, attempts, average score, pass rate, recent attempts (from DB).

## 7. Non-Functional Requirements
Security (hashing, JWT, rate limiting on login, parameterised SQL), performance (indexes, server-side pagination), responsiveness (desktop and mobile), reliability (transactions on submit), documentation (README, API list).

## 8. UI Workflow
```
Login -> role check
  Teacher: Dashboard -> Students | Quizzes -> Questions | Results -> Export CSV
  Student: My Quizzes -> Start Quiz -> Timer + Questions -> Submit -> Result -> History
```
Layout: compact left sidebar, white/light-grey background, navy accent, clean tables, simple forms.

## 9. ER Diagram
```mermaid
erDiagram
  USERS ||--o{ QUIZZES : creates
  USERS ||--o{ ATTEMPTS : takes
  QUIZZES ||--o{ QUESTIONS : contains
  QUIZZES ||--o{ ATTEMPTS : has
  ATTEMPTS ||--o{ ANSWERS : records
  QUESTIONS ||--o{ ANSWERS : answered_in
  USERS { int id PK string name string email UK string password_hash string role string roll_no }
  QUIZZES { int id PK string title int duration_minutes int pass_marks bool is_published int created_by FK }
  QUESTIONS { int id PK int quiz_id FK string text string option_a string option_b string option_c string option_d char correct_option int marks }
  ATTEMPTS { int id PK int quiz_id FK int student_id FK timestamp started_at timestamp submitted_at int score int total_marks string status }
  ANSWERS { int attempt_id PK int question_id PK char selected_option bool is_correct }
```

## 10. Database Design Notes
- Third normal form; the answers table links attempts and questions.
- Unique (quiz_id, student_id) on attempts enforces one attempt per quiz.
- Indexes: users(role), quizzes(is_published), questions(quiz_id), attempts(quiz_id), attempts(student_id), attempts(submitted_at).
- Trigram indexes (pg_trgm) speed up partial-text search on names and titles.
