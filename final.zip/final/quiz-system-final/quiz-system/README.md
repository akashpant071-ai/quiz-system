# Online Quiz Management System

B.Tech TQM Project - React + Vite, Node.js + Express, PostgreSQL.

## Easiest start on Windows (Supabase)
Double-click `START.bat`. It asks for your Supabase database password once, creates `server/.env`,
installs packages, creates the tables, adds demo data, starts both servers and opens the browser.
Next time, double-click `START.bat` again and it starts straight away.

## Project structure
```
quiz-system/
  docs/            SRS.md, API.md, samples/ (CSV files)
  server/          Express REST API
    db/            schema.sql, seed.js
    src/           config, middleware, routes, index.js
  client/          React + Vite frontend (Step 3)
```

## Build status
| Step | Content | Status |
|------|---------|--------|
| 1 | Structure, SRS, DB schema, seed, API foundation + auth | Done |
| 2 | CRUD APIs, search/pagination, CSV import/export, dashboard, quiz attempt + grading | Done (tested) |
| 3 | React frontend (teacher and student screens) | Done (tested in browser) |
| 4 | Review 1 and Review 2 documents, demo checklist | Next |

## Setup (server)
1. Install Node.js 18+ and PostgreSQL 14+.
2. Create the database:
   ```
   createdb quizdb
   ```
3. Configure environment:
   ```
   cd server
   cp .env.example .env     # edit DATABASE_URL and JWT_SECRET
   npm install
   ```
4. Create tables and seed data:
   ```
   npm run db:init
   npm run db:seed
   ```
5. Start the API:
   ```
   npm run dev              # http://localhost:5000/api/health
   ```

## Setup (client)
In a second terminal, with the server running:
```
cd client
npm install
npm run dev              # http://localhost:5173 (proxies /api to port 5000)
```
Open http://localhost:5173 and log in with a demo account below. `npm run build` creates a production build in `client/dist`.

## Demo accounts (after seeding)
| Role | Email | Password |
|------|-------|----------|
| Teacher/Admin | teacher@quiz.local | Teacher@123 |
| Student | student1@quiz.local ... student5@quiz.local | Student@123 |

Change these before any real deployment.

## Test login
```
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"teacher@quiz.local","password":"Teacher@123"}'
```

## API and CSV import
See `docs/API.md` for all endpoints and CSV formats. Sample files: `docs/samples/students_sample.csv` and `docs/samples/questions_sample.csv` (each has one deliberately invalid row to show validation).

## Screens
| Role | Screen | Purpose |
|------|--------|---------|
| Teacher | Dashboard | Live totals, recent attempts, per-quiz statistics |
| Teacher | Students | Search, sort, paginate, add, edit, delete, import CSV |
| Teacher | Quizzes | Search, filter by status, create, edit, publish, delete |
| Teacher | Questions | Per-quiz question CRUD and CSV import |
| Teacher | Results | Filters, summary, CSV export, answer review |
| Student | My quizzes | Published quizzes with Start, Resume or View result |
| Student | Quiz | Countdown timer, question navigator, auto-submit at zero |
| Student | Result / My results | Score, pass or fail, answer review, history |

Screenshots are in `docs/screenshots/`.
